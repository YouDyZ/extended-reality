export const female = {
    /*
				maxcomponent: 5,
				maxdraw: 1,
				maxtexture: //,
				maxpalet: 0 //Immer auf 0
				
				component: ,//Int (Aktuelle component Id)
				draw: ,//Array (Variation)
				texture: ,//Array (Texture)
				palet: //Int/Array (wahscheinlich immer 0)
	*/
    pedComponent: {
        head: [],
        mask: [
            {
                component: 1,
                draw: 0,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 1,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 2,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 3,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 5,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 6,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 8,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 9,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 10,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 11,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 12,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 4,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 14,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
                palet: 0
            },
            {
                component: 1,
                draw: 16,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8],
                palet: 0
            },
            {
                component: 1,
                draw: 17,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 18,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 19,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 20,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 21,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 22,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 23,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 24,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 25,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 26,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 7,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 27,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 28,
                texture: [0, 1, 2, 3, 4],
                palet: 0
            },
            {
                component: 1,
                draw: 29,
                texture: [0, 1, 2, 3, 4],
                palet: 0
            },
            {
                component: 1,
                draw: 30,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 31,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 32,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 33,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 34,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 35,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 36,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 37,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 38,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 39,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 40,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 41,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 42,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 43,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 44,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 45,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 46,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 47,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 48,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 49,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 50,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
                palet: 0
            },
            {
                component: 1,
                draw: 51,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
                palet: 0
            },
            {
                component: 1,
                draw: 13,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 15,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 52,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                palet: 0
            },
            {
                component: 1,
                draw: 53,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8],
                palet: 0
            },
            {
                component: 1,
                draw: 56,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8],
                palet: 0
            },
            {
                component: 1,
                draw: 57,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21],
                palet: 0
            },
            {
                component: 1,
                draw: 58,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
                palet: 0
            },
            {
                component: 1,
                draw: 59,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 60,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 61,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 62,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 63,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 64,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 65,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 66,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 67,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 68,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 69,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 70,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 71,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 72,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 73,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 74,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 76,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 77,
                texture: [0, 1, 2, 3, 4, 5],
                palet: 0
            },
            {
                component: 1,
                draw: 75,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 54,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                palet: 0
            },
            {
                component: 1,
                draw: 80,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 81,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 55,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 83,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 84,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 82,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 78,
                texture: [0, 1],
                palet: 0
            },
            {
                component: 1,
                draw: 85,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 86,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 87,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 88,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 89,
                texture: [0, 1, 2, 3, 4],
                palet: 0
            },
            {
                component: 1,
                draw: 90,
                texture: [0, 1, 2, 3, 4, 5, 6, 7],
                palet: 0
            },
            {
                component: 1,
                draw: 91,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                palet: 0
            },
            {
                component: 1,
                draw: 92,
                texture: [0, 1, 2, 3, 4, 5],
                palet: 0
            },
            {
                component: 1,
                draw: 93,
                texture: [0, 1, 2, 3, 4, 5],
                palet: 0
            },
            {
                component: 1,
                draw: 94,
                texture: [0, 1, 2, 3, 4, 5],
                palet: 0
            },
            {
                component: 1,
                draw: 95,
                texture: [0, 1, 2, 3, 4, 5, 6, 7],
                palet: 0
            },
            {
                component: 1,
                draw: 96,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 97,
                texture: [0, 1, 2, 3, 4, 5],
                palet: 0
            },
            {
                component: 1,
                draw: 98,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 99,
                texture: [0, 1, 2, 3, 4, 5],
                palet: 0
            },
            {
                component: 1,
                draw: 100,
                texture: [0, 1, 2, 3, 4, 5],
                palet: 0
            },
            {
                component: 1,
                draw: 101,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
                palet: 0
            },
            {
                component: 1,
                draw: 102,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 103,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 104,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 105,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23],
                palet: 0
            },
            {
                component: 1,
                draw: 106,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 107,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23],
                palet: 0
            },
            {
                component: 1,
                draw: 108,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23],
                palet: 0
            },
            {
                component: 1,
                draw: 109,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
                palet: 0
            },
            {
                component: 1,
                draw: 110,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 111,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 112,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 113,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21],
                palet: 0
            },
            {
                component: 1,
                draw: 114,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 115,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 116,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 117,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
                palet: 0
            },
            {
                component: 1,
                draw: 118,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 119,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],
                palet: 0
            },
            {
                component: 1,
                draw: 120,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 121,
                texture: [0],
                palet: 0
            },
            {
                component: 1,
                draw: 122,
                texture: [0, 1, 2],
                palet: 0
            },
            {
                component: 1,
                draw: 124,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23],
                palet: 0
            },
            {
                component: 1,
                draw: 123,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
                palet: 0
            },
            {
                component: 1,
                draw: 125,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 126,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
                palet: 0
            },
            {
                component: 1,
                draw: 127,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 128,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
                palet: 0
            },
            {
                component: 1,
                draw: 129,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
                palet: 0
            },
            {
                component: 1,
                draw: 130,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18],
                palet: 0
            },
            {
                component: 1,
                draw: 131,
                texture: [0, 1, 2, 3],
                palet: 0
            },
            {
                component: 1,
                draw: 132,
                texture: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25],
                palet: 0
            },
            {
                component: 1,
                draw: 79,
                texture: [0, 1, 2],
                palet: 0
            }
        ],
        hair: [
            {
                component: 2,
                draw: 0,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 1,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 2,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 3,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 4,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 5,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 6,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 7,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 8,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 9,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 10,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 11,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 12,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 13,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 14,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 15,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 16,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 17,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 18,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 19,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 20,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 21,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 22,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 23,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 24,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 25,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 26,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 27,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 28,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 29,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 30,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 31,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 32,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 33,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 34,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 35,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 36,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 37,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 38,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 39,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 40,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 41,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 42,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 43,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 44,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 45,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 46,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 47,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 48,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 49,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 50,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 51,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 52,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 53,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 54,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 55,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 56,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 57,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 58,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 61,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 59,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 60,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 62,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 63,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 64,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 65,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 66,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 67,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 68,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 69,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 70,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 71,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 72,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 73,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 74,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 75,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 76,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 77,
                texture: [0],
                palet: 0
            },
            {
                component: 2,
                draw: 78,
                texture: [0],
                palet: 0
            }
        ],
        torso: [
            {
                component: 3,
                draw: 0,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 1,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 2,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 3,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 4,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 5,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 6,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 7,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 8,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 9,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 10,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 11,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 12,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 13,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 14,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 15,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 16,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 17,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 18,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 19,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 20,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 21,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 22,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 23,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 24,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 25,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 26,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 27,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 28,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 29,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 30,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 31,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 32,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 33,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 34,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 35,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 36,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 37,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 38,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 39,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 40,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 41,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 42,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 43,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 44,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 45,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 46,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 47,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 48,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 49,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 50,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 51,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 52,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 53,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 54,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 55,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 56,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 57,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 58,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 59,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 60,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 61,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 62,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 63,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 64,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 65,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 66,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 67,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 68,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 69,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 70,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 71,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 72,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 73,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 74,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 75,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 76,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 77,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 78,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 79,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 80,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 81,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 82,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 83,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 84,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 85,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 86,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 87,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 88,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 89,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 90,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 91,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 92,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 93,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 94,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 95,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 96,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 97,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 98,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 99,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 100,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 101,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 102,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 103,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 104,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 105,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 106,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 107,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 108,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 109,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 110,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 111,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 112,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 113,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 115,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 116,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 114,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 117,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 118,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 119,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 120,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 121,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 122,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 123,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 124,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 125,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 126,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 127,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 128,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 129,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 130,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 131,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 132,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 133,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 134,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 135,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 136,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 137,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 138,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 139,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 140,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 141,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 142,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 143,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 144,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 145,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 146,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 147,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 148,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 149,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 150,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 151,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 152,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 153,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 154,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 155,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 156,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 157,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 158,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 159,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 160,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 161,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 162,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 163,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 164,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 165,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 166,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 167,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 168,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 169,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 170,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 171,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 172,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 173,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 174,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 175,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 176,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 177,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 178,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 179,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 180,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 181,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 182,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 183,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 184,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 185,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 186,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 187,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 188,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 189,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 190,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 191,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 192,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 193,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 194,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 195,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 196,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 197,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 198,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 199,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 200,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 201,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 202,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 203,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 204,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 205,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 206,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 207,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 208,
                texture: [0],
                palet: 0
            },
            {
                component: 3,
                draw: 209,
                texture: [0],
                palet: 0
            }
        ],
        legs: []
    }
};
