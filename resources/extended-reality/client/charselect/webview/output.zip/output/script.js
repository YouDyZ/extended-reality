let apiM = import('./api/male.js');
let apiF = import('./api/female.js');

//Event listener
window.addEventListener('load', function() {
    let maskdraw = document.getElementById('maskdraw');

    maskdraw.addEventListener('input', function() {
        let value = maskdraw.value;
        maskdraw.value = parseInt(maskdraw.value);
        if (isNaN(value)) return;
        else if (value >= apiM.pedComponent.mask.length) {
            console.log(value);
            let last = apiM.pedComponent.mask.length - 1;
            maskdraw.value = apiM.pedComponent.mask[last].draw;
            let texture = document.getElementById('masktextture');
            texture.value = `${apiM.pedComponent.mask[maskdraw.value - 1].texture[0]}`;

            //EmitChange
        } else if (value < 0) {
            maskdraw.value = 0;
            let texture = document.getElementById('masktextture');
            texture.value = `${apiM.pedComponent.mask[0].texture[0]}`;

            //EmitChange
        }
    });

    //Mask Texture
    let masktextture = document.getElementById('masktextture');
    masktextture.addEventListener('input', function() {
        let value = masktextture.value;
        let drawobject = parseInt(maskdraw.value);
        let length = apiM.pedComponent.mask[drawobject - 1].texture.length;
        masktextture.value = parseInt(masktextture.value);
        if (isNaN(value)) return;
        else if (value >= length) {
            let last = apiM.pedComponent.mask[drawobject - 1].texture.length - 1;
            console.log('last: ' + last);
            masktextture.value = `${apiM.pedComponent.mask[drawobject - 1].texture[last]}`;
        } else if (value < 0) {
            masktextture.value = `${apiM.pedComponent.mask[drawobject - 1].texture[0]}`;
        }
    });
    //console.log(input);
});

let drawprev = function(component) {
    if (component == 'mask') {
        let maskdraw = document.getElementById('maskdraw');
        let courrent = parseInt(maskdraw.value);
        let texture = document.getElementById('masktextture');

        if (courrent == 0) {
            console.log('Bereits erster');
            //-> Button prev == style {gray}
        } else {
            //console.log(`${apiM.pedComponent.mask[courrent].draw}`);

            courrent = courrent - 1;
            maskdraw.value = `${courrent}`;
            texture.value = `${apiM.pedComponent.mask[courrent - 1].texture[0]}`;
        }
    } else {
        console.log('err');
    }
};

const drawnext = function(component) {
    if (component == 'mask') {
        let maskdraw = document.getElementById('maskdraw');
        let courrent = parseInt(maskdraw.value);
        let texture = document.getElementById('masktextture');

        if (courrent == apiM.pedComponent.mask.length) {
            console.log('Bereits letzter');
            //-> Button next == style {gray}
        } else {
            //console.log(`${apiM.pedComponent.mask[courrent].draw}`);

            courrent = courrent + 1;
            maskdraw.value = `${courrent}`;
            texture.value = `${apiM.pedComponent.mask[courrent - 1].texture[0]}`;
        }
    } else {
        console.log('err');
    }
};

const textureprev = function(component) {
    if (component == 'mask') {
        let mask = parseInt(document.getElementById('maskdraw').value);
        let texture = document.getElementById('masktextture');
        let courrent = parseInt(texture.value);
        if (courrent == 0) {
            //-> Button prev == style {gray}
            console.log('Bereits erster');
        } else {
            //console.log(`${apiM.pedComponent.mask[courrent].draw}`);

            courrent = courrent - 1;
            //maskdraw.value = `${courrent}`;
            texture.value = `${apiM.pedComponent.mask[mask - 1].texture[courrent]}`;
        }
    }
};

const texturenext = function(component) {
    if (component == 'mask') {
        let mask = parseInt(document.getElementById('maskdraw').value);
        let texture = document.getElementById('masktextture');
        let courrent = parseInt(texture.value);
        if (isNaN(courrent)) {
            texture.value = `${apiM.pedComponent.mask[mask - 1].texture[0]}`;
        } else if (courrent + 1 == apiM.pedComponent.mask[mask - 1].texture.length) {
            //-> Button next == style {gray}
            console.log('Bereits letzte');
        } else {
            console.log(`${courrent}`);

            courrent = courrent + 1;
            //maskdraw.value = `${courrent}`;
            texture.value = `${apiM.pedComponent.mask[mask - 1].texture[courrent]}`;
        }
    }
};
